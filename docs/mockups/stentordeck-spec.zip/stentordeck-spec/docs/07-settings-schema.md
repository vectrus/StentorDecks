# 07 — Settings schema

Stored as `settings.json` in `app.getPath('userData')`, written atomically (temp + rename), validated with zod on load; invalid file → back up aside, use defaults, notify. Values below are the defaults.

```jsonc
{
  "version": 1,

  "audio": {
    "masterDevice": null,          // WASAPI device id; null = show setup screen
    "masterChannels": [0, 1],
    "cueDevice": null,
    "cueChannels": [2, 3],
    "routingPlan": "auto",         // "auto" | "A" | "B" (auto = probe, see docs/02)
    "bufferHintMs": 23,            // maps to AudioContext latencyHint
    "brakeOnStop": false,
    "brakeMs": 400,
    "inputs": { "enabled": false } // reserved; devices enumerated + displayed only (R1.4)
  },

  "mixer": {
    "crossfader": { "enabled": false },              // R2.4 — default OFF
    "channelFaders": {
      "linked": true,
      "a": { "shape": 35 },                          // -100..100, see docs/03
      "b": { "shape": 35 }
    },
    "pitchFaders": {
      "range": 0.08,                                 // ±8 %
      "centerDeadZone": 0.04                         // 0..0.10
    }
  },

  "fx": {
    "flanger": { "rateHz": 0.25, "depthMs": 1.5, "feedback": 0.5 }
  },

  "library": {
    "roots": [],                                     // absolute paths; ≥1 required after setup
    "purgeMissingAfterDays": 30
  },

  "ui": {
    "scale": 100,                                    // 100 | 125 | 150
    "deckAColor": "#FFB454",
    "deckBColor": "#5BD0FF",
    "startInFullscreen": true,
    "startMode": "performance"                       // "performance" | "prep"
  },

  "midi": {
    "preferredPort": null,                           // substring match; null = auto ("RMX")
    "sendLeds": true
  }
}
```

Rules:
- Every setting change is applied live (no restart), through `SettingsStore` reactions; audio device/plan changes rebuild the graph per docs/02.
- Any software-side value change caused by a settings change re-arms soft takeover on affected controls.
- First run (`masterDevice === null` or `roots` empty) opens the Audio setup screen, then the library root picker, before entering Performance mode.
- The MIDI mapping itself lives in SQLite (docs/04), not here — settings hold only port preference and LED toggle.
```
