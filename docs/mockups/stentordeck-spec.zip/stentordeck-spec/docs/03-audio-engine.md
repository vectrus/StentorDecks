# 03 — Audio engine

All nodes Web Audio, master context (Plan A shown; Plan B differs only at the output stage).

## Per-deck graph

```
AudioBufferSourceNode (playbackRate = pitch × nudge)
  → trimGain            (GAIN knob, -∞..+12 dB, default 0 dB)
  → eqLow   BiquadFilter lowshelf   f=180 Hz
  → eqMid   BiquadFilter peaking    f=1 kHz, Q=0.9
  → eqHigh  BiquadFilter highshelf  f=4.5 kHz
  → killLow/Mid/High     (implemented as the same biquads driven to -40 dB, 15 ms ramp)
  → fx chain (see below)
  → pflTap ──────────────────────────────► cue bus (pre-fader listen)
  → faderGain           (channel fader, curve-mapped, see Fader curves)
  → [crossfaderGain]    (BYPASSED by default: node present, gain fixed at 1, no automation;
                         hardware crossfader CC ignored unless settings.crossfader.enabled)
  → master bus
```

Master bus → masterGain (hardware master volume CC) → DynamicsCompressor as safety limiter (threshold -1 dB, ratio 20, knee 0) → merger ch 0/1.

Cue bus: per-deck pflTap gains (0/1, 15 ms ramp) → cueSum; headphone output = blend(cueSum, master bus) via equal-power cue/mix crossfade (hardware HeadMix CC) → headphoneGain (hardware phones volume) → merger ch 2/3.

## Transport

- Play: create a fresh `AudioBufferSourceNode` at `ctx.currentTime`, remember `(startCtxTime, startOffset)`. Pause: stop node, compute offset. Seek/cue: same mechanism. Sources are throwaway; the decoded `AudioBuffer` is deck state.
- Position for UI/waveform derived each rAF: `offset + (ctx.currentTime - startCtxTime) × playbackRate` (integrate across rate changes: accumulate on every rate change).
- Nudge (jog while playing): rate multiplier 1 ± 0.02 × velocityFactor, decays to 1 over 250 ms after last tick. Jog while paused: seek ±20 ms per tick.
- Pitch: `rate = 1 + pitchFaderValue × 0.08`. Effective BPM = fileBPM × rate (drives the big readout).
- SYNC: one-shot — set `pitchFaderValue` so effectiveBPM(this) = effectiveBPM(other); pitch fader enters soft-takeover pickup. Released by loading (R3.3) or moving the pitch fader through pickup.
- Brake (optional, default off): on stop, ramp playbackRate → 0 over 400 ms, then stop.
- Load interlock: `DeckStore.load()` throws `DeckPlayingError` if `state === playing`; every input path routes through this one method (R4.2).
- Deck reset on load: FX off + wet reset, kills released, nudge cleared, sync released, cue point cleared, pitch **value** kept at fader's logical value but re-armed for takeover. Reverb-style tails don't exist (no time-based master FX), so reset is instant and click-free via 15 ms gain ramps.

## Fader curves (R2.5, R2.6)

Chain per continuous control: `raw14bit → normalize 0..1 → shape → domain map`.

- Channel faders: `shaped = pos^(2^(s/50))` with shape `s ∈ [-100..100]` (0 = linear, positive = fine control at top). Domain map: `gain = 0` at pos 0, else `dB = -60 + shaped × 60`, `gain = 10^(dB/20)`. Presets: linear s=0, smooth s=35, sharp s=-45. Per-fader setting, mirrored by default (`linked: true`).
- Pitch faders: linear, then center dead-zone: `|pos-0.5| < deadZone/2 → 0.00 %` with continuous remap outside the zone (no jump at the edge). `deadZone` default 0.04, range 0–0.10.
- Curve is applied **after** soft-takeover comparison: takeover compares raw hardware position against the raw position corresponding to the current software value (inverse-map), so pickup feel is independent of curve.

## Soft takeover (R2.7)

Applies to: channel faders, pitch faders, gain, EQ ×3 ×2, wet knobs, master, headMix, phones.
State per control: `armed` (bool) + last hardware raw. Armed on: app start, MIDI reconnect, any software-side change of the value (sync, load-reset, UI drag, preset). While armed, incoming hardware values are ignored until hardware crosses the software value (or comes within 1/128); then control goes live. `MidiStore` exposes `{softwareValue, hardwareValue, armed}` per control; UI renders the hollow pickup marker from this (R7 / style guide).

## Effects (R3)

Insert chain: `input → [filter] → [flanger] → output`, each independently bypassable (true bypass via routing, 15 ms crossfade to avoid clicks).

**Filter** — one BiquadFilter. Knob 0..1, center 0.5 = bypass. Left half: lowpass, cutoff 20 kHz → 80 Hz (log). Right half: highpass, 20 Hz → 8 kHz (log). Q ramps 0.7 → 8 toward the extremes. Knob within ±0.03 of center snaps to bypass.

**Flanger** — split dry/wet; wet path: DelayNode (base 2 ms) with LFO (OscillatorNode sine → GainNode depth → delayTime), feedback GainNode loop. Params: rate 0.05–2 Hz (default 0.25), depth 0.5–3 ms (default 1.5), feedback 0–0.85 (default 0.5), wet 0–1 (WET knob, equal-power mix). Defaults tuned by ear on real material before E6 closes.

Pad behavior: pad toggles the effect on/off (latching). Active effect state must be visually loud (R3.2).

## Metering

Per channel + master: `AnalyserNode` (fftSize 2048) read each rAF; RMS → dB. VU zones: green < -9 dBFS, amber -9..-3, red > -3 (post-fader, pre-master for channels; post-limiter-input for master clip light). Meters live beside faders (style guide).
