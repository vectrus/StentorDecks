# 01 — Requirements (locked)

Source: design sessions with the owner (DJ, 54, declining eyesight, RMX2 hardware, HP i7/64GB laptop). Changes to this file require owner sign-off; everything else derives from it.

## R1 Hardware & platform
- R1.1 Windows 10/11 x64 native app, distributed as an installer. Runs offline.
- R1.2 Launches directly into fullscreen (no title bar/taskbar). `Esc` or corner button exits fullscreen; the app remains usable windowed for development.
- R1.3 Hercules DJConsole RMX2 is the reference controller: MIDI in/out and 4-out/4-in USB sound card.
- R1.4 Soundcard routing is configurable in-app: master output (default RMX2 outputs 1-2 → sound system) and cue output (default RMX2 outputs 3-4 → headphones) are independently selectable devices/channel pairs. Inputs (mic, line 1-2) are enumerated and displayed but not routable in v1 ("coming later" state) — the settings model must already contain them.
- R1.5 The app must remain fully operable with mouse/keyboard when the RMX2 is disconnected, and must hot-reconnect the controller without restart.

## R2 Playback & mixing
- R2.1 Two decks, MP3 + FLAC + WAV.
- R2.2 Jog wheels: nudge (temporary tempo bend while playing) and seek (while paused) only. No scratching. Latency target ≤ 40 ms output; no ASIO requirement.
- R2.3 Beatmatching is manual-first: pitch faders ±8 %, pitch-bend buttons, jog nudge. SYNC button per deck sets that deck's rate so its BPM equals the other deck's current effective BPM. No beatgrid phase-locking. No keylock (pitch changes tone; acceptable).
- R2.4 No crossfader. The engine contains a bypassed crossfader stage; hardware crossfader MIDI is ignored; no crossfader appears in the UI. A settings toggle (default off) can enable it for guests.
- R2.5 Channel faders are the mixing instrument. Per-fader response: position→dB mapping with a user-adjustable curve (presets linear/smooth/sharp + continuous shape control); A and B curves mirrored by default, unlinkable.
- R2.6 Pitch faders: near-linear curve, plus configurable center dead-zone that snaps to exactly 0.00 %.
- R2.7 Soft takeover on all continuous hardware controls (faders, knobs). UI shows a pickup indicator (hollow marker at physical position) whenever software and hardware values diverge.
- R2.8 Headphone cue: per-deck cue (PFL) toggle from hardware and UI; cue/mix blend and headphone volume from the hardware knobs. Deck cue state is always visible on screen.
- R2.9 Optional brake ("vinyl stop") on the stop action, off by default.

## R3 Effects
- R3.1 Exactly two effects per deck: resonant filter (single knob, LP left of center / HP right) and flanger (rate, depth, feedback; wet/dry). Triggered from RMX2 pads and UI buttons.
- R3.2 An active effect is visually loud in the UI (lit accent + wet amount).
- R3.3 Deck reset on load (hard rule): loading a track switches all FX off and resets wet/dry, releases EQ kills, releases pitch bend, releases sync, clears the cue point. Physical knob positions are reconciled via soft takeover.

## R4 Loading & interlocks
- R4.1 Load into a deck via: hardware load buttons, per-deck UI Load button, double-click in browser.
- R4.2 A playing deck cannot receive a track, from any input path. The attempt triggers a visible rejection flash on the deck ("Deck A is playing"). Paused/stopped decks load normally. No override in v1.
- R4.3 The Load control displays a lock state while its deck is playing.

## R5 Library
- R5.1 Library size 500–5000 tracks. Disk folders are the organizational structure ("crates"); the app never moves/renames files.
- R5.2 Browser offers a folder tree mirroring the watched music directories plus flat search across the whole library (artist/title/filename).
- R5.3 RMX2 browse cluster: up/down moves selection, right enters folder, left goes to parent.
- R5.4 Watched folders are monitored; new/changed/removed files are picked up automatically.
- R5.5 All analysis results (BPM, key, duration, tags, waveform peaks) persist in SQLite. Keyed on path + size + mtime, with a partial content hash so moved/renamed files keep their analysis. A track is analyzed at most once per content.

## R6 Analysis
- R6.1 BPM detection tuned for 70–180 BPM electronic/dance material; existing TBPM/BPM tags are trusted and skip analysis (marked `tag` source, re-analyzable on demand).
- R6.2 Key detection displayed Camelot-first (e.g. `8A`), musical name secondary. Existing key tags trusted as above.
- R6.3 Analysis runs as a background queue that never blocks UI or audio; progress visible in the browser.
- R6.4 Waveforms: full-track overview + detail peaks for the scrolling view, pre-rendered during analysis and cached.

## R7 UI & accessibility
- R7.1 Readable at ~1 m in a dark room: near-white on near-black, minimum 14 px for any interactive text, browser rows ≥ 16 px / 42 px tall, BPM readout ≥ 40 px, time-remaining ≥ 22 px.
- R7.2 UI scale setting: 100 / 125 / 150 %.
- R7.3 Deck accent colors configurable (defaults: A amber `#FFB454`, B cyan `#5BD0FF`).
- R7.4 Two modes, both fullscreen: Performance (waveforms + decks + mixer + 3-row browser) and Prep (compact deck strips + folder tree + large browser). Toggle via UI and mappable hardware control.
- R7.5 Waveform strip: both decks stacked, fixed center playhead, deck-colored.
- R7.6 VU meters beside channel faders: green → amber, red only at clipping.
- R7.7 Size = importance: mid-mix data (BPM, remaining time, key, VU) is the largest; prep-time data is smaller or moved to Prep mode.

## R8 MIDI
- R8.1 RMX2 factory mapping works out of the box (see docs/04). 14-bit CC pairs honored for faders; jog relative encoding honored.
- R8.2 MIDI-learn mode: click a UI control, move a hardware control, mapping stored. Export/import mapping as JSON.
- R8.3 A MIDI monitor panel (dev/settings area) shows the live message stream for debugging.
